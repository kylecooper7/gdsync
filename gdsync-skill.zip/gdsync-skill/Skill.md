---
name: Google Docs Editor
description: Read, edit, and comment on Google Docs via a local content file. Use when asked to work with Google Docs, address doc comments, or make document edits.
dependencies: "@gdsync/gdsync"
---

# Google Docs Editor

Edit Google Docs through a local `content.txt` file using the `gdsync` CLI. Fetch a doc, edit the file, commit changes back. Also read and reply to comments.

## Getting Started

If `gdsync` is not installed:
```bash
npm install -g @gdsync/gdsync
```

### Step 1 — Authenticate

1. Run `gdsync auth` — prints a sign-in URL and exits immediately
   - If already authenticated: prints "Already authenticated" — skip to Step 2
2. Share the URL with the user: **"Please sign into the Google account you want to use for document editing."**
3. After the user confirms they signed in, run `gdsync auth check`
   - Exit code 0 = success, proceed to Step 2
   - Exit code 1 = not yet signed in, wait and retry
   - Exit code 2 = session expired or failed, run `gdsync auth` again

### Step 2 — Find the document

If the user gives you a document ID, skip to Step 3.

Otherwise, list available docs:
```
gdsync docs
```

Shows all Google Docs accessible to the authenticated account (including shared docs). Use `--search "keyword"` to filter by name.

### Step 3 — Initialize

```
gdsync init --doc <documentId>
```

The document ID is the long string in the Google Docs URL: `https://docs.google.com/document/d/THIS_IS_THE_ID/edit`

## Editing Workflow

### 1. Fetch

```
gdsync fetch
```
Always fetch first — content.txt may be stale.

### 2. Read

Read `content.txt` for content. Read `comments.txt` for feedback.

### 3. Edit

Edit `content.txt` directly.

### 4. Commit

```
gdsync commit
```
Always commit after editing.

### 5. Check Result

- `"Committed."` + `"Verified — document matches."` = success
- Error = fix and retry, or `gdsync fetch` to reset

## Content File Format

### Blocks

```
---blk_1 paragraph---
# Document Title

---blk_2 paragraph---
Text with **bold** and *italic*.

---blk_3 list_item---
- A list item

---blk_4 table---
| H1 | H2 |
| -- | -- |
| C1 | C2 |

---blk_5 image---
![alt](assets/img_001.png)
```

Type tokens: `paragraph`, `list_item`, `table`, `image`. Don't change them.

### Adding / Deleting / Reordering

- **Add:** Insert bare `---` delimiter (no ID)
- **Delete:** Remove delimiter and content entirely
- **Reorder:** Move delimiter and content to new position

### Formatting

- `**bold**`, `*italic*`, `` `code` ``, `[link](url)`
- Headings: `# H1` through `###### H6`
- Lists: `- ` unordered, `1. ` ordered (2-space indent for nesting)
- Tables: markdown syntax, edit cells only (no row/column changes)
- Images: reference files in `assets/` (must exist before commit)
- Readonly blocks (`readonly` token): do not edit

## Comments

`comments.txt` is read-only. Use CLI commands to act on comments.

```
gdsync comment reply <threadId> "<message>"
gdsync comment resolve <threadId> --reply "<message>"
gdsync comment create <blockId> "<message>" --anchor "<text>"
```

**Always reply, never resolve.** Let the user review and resolve.

## Settings

```
gdsync config mode auto              # direct edits (default)
gdsync config mode suggestions       # strikethrough + red suggestions
gdsync config comment_filter on      # only @mentioned comments
```

## Own GCP Project (Optional)

For dedicated rate limits, the user can set up their own GCP project:

1. `gdsync setup auto` — prints setup wizard URL
2. User completes setup in browser
3. `gdsync setup check` — confirms credentials saved
4. `gdsync auth` / `gdsync auth check` — authenticate with new project

Or manually: set `GOOGLE_CLIENT_ID` + `GOOGLE_CLIENT_SECRET` env vars, run `gdsync setup manual`, then `gdsync auth`.

## Rules

1. **Always fetch before editing**
2. **Always commit after editing**
3. **Never edit readonly blocks**
4. **Never assign block IDs** — use bare `---`
5. **Don't change type tokens**
6. **Image files must exist** before commit
7. **One task at a time** — fetch, edit, commit before the next
8. **Never edit comments.txt**
9. **Reply to comments, don't resolve**

## Error Recovery

- **Commit fails:** Read error, fix, retry
- **Something wrong:** `gdsync fetch` to reset
- **Process crashed:** `gdsync reset` then `gdsync fetch`
- **Not authenticated:** `gdsync auth`, share URL, `gdsync auth check`

## Command Reference

| Command | What it does |
|---|---|
| `gdsync auth` | Start authentication |
| `gdsync auth check` | Check if auth is complete |
| `gdsync docs` | List accessible Google Docs |
| `gdsync docs --search "x"` | Search docs by name |
| `gdsync init --doc <id>` | Initialize sync for a document |
| `gdsync fetch` | Pull latest doc into content.txt |
| `gdsync commit` | Push edits to Google Doc |
| `gdsync status` | Show sync session state |
| `gdsync reset` | Wipe session, re-fetch |
| `gdsync config` | View/change settings |
| `gdsync comment reply <id> "msg"` | Reply to a comment |
| `gdsync comment resolve <id>` | Resolve a comment |
| `gdsync comment create <blk> "msg"` | Create a comment |
| `gdsync setup auto` | Guided GCP project setup |
| `gdsync setup check` | Check setup completion |
| `gdsync setup manual` | Check for manual credentials |
